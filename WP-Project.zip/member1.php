<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="assets/css/stylemember.css">
  <title>Member 1</title>
</head>
<body style=" background-image: url(assets/images/memberbg.png); no-repeat center">
  <div id="header"></div>
  <div class="profile-card">
     <div class="top-section">
      <div class="pic">
         <img src="assets/images/kx.jpg" alt="" width="50%"height="50%">
       </div> <br>
        <div class="name">Cheah Kah Xuan</div>
        <div class="sname">Matric.No: <span>A19DW0253</span></div>
        <div class="sname">Section: <span>40</span></div>
     </div>

     <div class="bottom-section">
       <div class="course">Diploma In Computer Science<br>(Internet Technology)</div>

     </div>

     <a href="page.php?type=aboutus">Return</a>
     <!-- <a href="resume1.html">view Resume</a> -->
  </div>
</body>
</html>
