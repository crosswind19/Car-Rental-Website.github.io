<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Index</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script>
$(function(){
  $('#header').load('header.php');
  $("#footer").load("footer.html");
});
</script>
  <link href="css/style.css" rel="stylesheet" />
</head>

<body style="background-image: url(img/wallpaper2.jpg);height:100%;width:100%">
  <div>
    <div id="header"></div>

    <div class="welcome">
    <h1>WELCOME</h1>
    <h6><b><i>To Our Page</i></b></h6>
    </div>



    <div id="footer"></div>
  </div>
</body>
</html>
