<footer>
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h6><b>Web Programming Project</b></h6>
          <h6>Presented by Group 3</h6>
          <ul>
            <li><a href="page.php?type=aboutus">About us</a></li>
            <li><a href="admin/">Admin Login</a></li>
            <li><a href="Assignment 1/home.php">Assignment 1</a></li>
          </ul>
        </div>

      </div>

    </div>

  </div>
</footer>
