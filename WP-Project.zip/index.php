<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-177875132-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-177875132-1');
</script>


    <script data-ad-client="ca-pub-2432708023082860" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    <meta charset="utf-8">
    <title>WP - Project | Welcome </title>
    <link rel="icon" href="../assets/img/2020.png">
    <link rel="stylesheet" href="hello.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">

  </head>
  <body>
    <div class="stage">
        <div class="wrapper">
            <div class="slash"></div>
            <div class="sides">
                <div class="side"></div>
                <div class="side"></div>
                <div class="side"></div>
                <div class="side"></div>
            </div>
            <div class="text">
                <div class="text--backing">WP_Project</div>
                <div class="text--left">
                    <div class="inner">WP_Project</div>
                </div>
                <div class="text--right">
                    <div class="inner">WP_Project</div>
                </div>
            </div>
        </div>
    </div>
    <script src="hello.js"></script>
    <!-- <script> window.location.href='home.php'; </script> -->
  </body>
</html>
